import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutterfrontenduniprojectmanager/core/database/local/providersAndForms/semester/form.dart';
import 'package:flutterfrontenduniprojectmanager/features/CoursesPage/presentation/page/courses_page.dart';
import 'package:flutterfrontenduniprojectmanager/features/UserAdditionalDataRequirementPage/presentation/page/page.dart';
import 'package:flutterfrontenduniprojectmanager/features/homepage/presentation/page/home_page.dart';
import 'package:flutterfrontenduniprojectmanager/features/homepage/presentation/page/settings_page.dart';
import 'package:flutterfrontenduniprojectmanager/features/loginpage/presentation/page/login_page.dart';
import 'package:flutterfrontenduniprojectmanager/features/waitingToverifyEmailPage/presentation/page/waiting_to_verfiy_email_page.dart';
import 'package:flutterfrontenduniprojectmanager/router/refresh_listen_able.dart';
import 'package:flutterfrontenduniprojectmanager/router/router_redirect_logique.dart';
import 'package:go_router/go_router.dart';

String? getCurrentLocation({Ref? ref, WidgetRef? widgetRef}) {
  ///we passed here both because we may need it inside a notifier , or a ui
  if (ref != null) {
    final router = ref.read(routerProvider);
    return router.routerDelegate.currentConfiguration.uri.toString();
  } else if (widgetRef != null) {
    final router = widgetRef.read(routerProvider);
    return router.routerDelegate.currentConfiguration.uri.toString();
  } else {
    return null;
  }
}

final navigatorKey = GlobalKey<NavigatorState>();

final routerProvider = Provider<GoRouter>((ref){

 final routerNotifier = RefreshListenAbleRouterNotifier(ref);

 return GoRouter(
    navigatorKey: navigatorKey,
    refreshListenable:routerNotifier ,
    
    initialLocation: '/home',
    redirect: (context, state) {
      //checking auth states , redirectResult used to be the result of chaining redirects 
      String? redirectResult = ref.read(routerRedirectLogiqueProvider.notifier).authRedirect(state);
      if (redirectResult != null){
        return redirectResult;
      }
      
      //checking if email verified
      redirectResult = ref.read(routerRedirectLogiqueProvider.notifier).emailVerificationRedirect(state);
      if(redirectResult != null){
        return redirectResult;
      }
      
      return null;
},
    routes: [
      GoRoute(
        path: '/login',
        builder: (context, state) {
          return LoginPage();
        },
      ),
      GoRoute(
        path: '/waitingToVerify',
         builder: (context, state) {
          return WaitingToVerfiyEmailPage();
        },

      ),
      GoRoute(
        path: '/home',
        builder: (context, state) {
          return HomePage();
        },
        routes: [
          GoRoute(
            path: 'settings',
            builder: (context, state) {
              return SettingsPage();
            },
            ),
            GoRoute(
              path:'courses',
              builder : (context , state){
                final semester = state.extra as Semester;
                return CoursesPage(semester: semester);
              },
              routes: [
                ///TODO , adding three routes , :courseuuid/images , .../videos , .../files

              ]
            )
        ]
      ),
      GoRoute(
        path: '/AdditionalDataSheet',
        builder: (context, state) {
          return  UserAdditionalDataRequirementPage();
        },
        )

    ],
  );

});


