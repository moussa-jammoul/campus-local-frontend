import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutterfrontenduniprojectmanager/features/Media/service/lastSynced/form.dart';


///this provider is used for fetching cloud data (note that it use the biggest updated_at media
///  , it is not relying to the precise time where we synced to
///the cloud) , already explained inside core/database/cloud/media domain
class LastSyncedData extends Notifier<LastSyncedForm?>{
  @override
  LastSyncedForm? build() {
    return null;
  }

  void updateLastSynced(LastSyncedForm data){
    state = data;
  }

}

final lastsyncedDataProvider =  NotifierProvider<LastSyncedData,LastSyncedForm?>((){
  return LastSyncedData();
});