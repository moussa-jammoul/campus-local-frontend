class LastSyncedForm {
  DateTime lastUpdateSynced;
  String lastUuidSynced;
  LastSyncedForm({
    required this.lastUpdateSynced,
    required this.lastUuidSynced
  });

}